//
//  FoundApp.swift
//  Found
//
//  Created by Chelsea She on 11/23/24.
//

import SwiftUI
import FirebaseCore
import GoogleSignIn
import Firebase

@main
struct FoundApp: App {
    
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    @ObservedObject var appState: AppState = AppState()
    
//    init() {
//        configureFirebase()
//    }
    
    var body: some Scene {
        WindowGroup {
            if appState.isLoggedIn {
                ContentView()
            }
            else {
                AuthView()
                    .environmentObject(appState)
            }
            
        }
    }
    
    func configureFirebase() {
        if FirebaseApp.app() == nil {
            FirebaseApp.configure()
        }
    }
}

class AppDelegate: NSObject, UIApplicationDelegate {
  func application(_ application: UIApplication,
                   didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
    FirebaseApp.configure()
    return true
  }
}
